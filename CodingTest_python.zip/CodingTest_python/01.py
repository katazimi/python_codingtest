def solution(arr):
    arr.sort()
    return arr
arr = [1,-5,2,4,3]
solution(arr)
print(arr)